package com.learning.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.learning.crud.repository.UserRepository;
import com.learning.crud.service.UserService;

@Controller
@RequestMapping("/view")
public class MainController {

	@Autowired
	UserRepository userrepo;
	@Autowired
	UserService userserv;

	@GetMapping
	public String showUserData(Model model) {
		model.addAttribute("users", userserv.findAllUser());
		return "view";
	}
}
