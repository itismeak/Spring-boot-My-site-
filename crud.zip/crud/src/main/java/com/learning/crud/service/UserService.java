package com.learning.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learning.crud.entity.User;
import com.learning.crud.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepo;
	
	public List<User> findAllUser() {
		return userRepo.findAll();
	}

	

	public Object getUserById(Long id) {
		return userRepo.getById(id);
	}
	
	
}
