package com.learning.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.learning.crud.service.UserService;

@Controller
@RequestMapping("/view/edit/{id}")
public class EditController {

	@Autowired
	UserService userServ;
	
	@GetMapping
	public String editUser(@PathVariable Long id, Model model) {
		model.addAttribute("employee", userServ.getUserById(id));
		return "view_employee";
	}
}
