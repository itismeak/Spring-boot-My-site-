package com.learning.crud.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.learning.crud.entity.User;
import com.learning.crud.repository.UserRepository;
import com.learning.crud.service.UserService;

@Controller
@RequestMapping("/register")
public class RegisterController {
	public static String uploadDirectory = System.getProperty("user.dir") + "/uploads";

	@Autowired
	public UserRepository userrepo;

	@Autowired
	public UserService userserv;

	@GetMapping
	public String registerShow() {
		return "register";
	}

	@PostMapping
	public String registerUser(@ModelAttribute("user")User user,BindingResult bindingResult, @RequestParam("file") MultipartFile file)
			throws IOException, IllegalStateException {
		String destPath = "D:/uploads/";

		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("MMM_dd_yyyy hh_mm_ss-");
		String strDate = dateFormat.format(date);
		
		//url+name of file 
		String destination = destPath + strDate + file.getOriginalFilename();
		//name of file
		String fileName = strDate + file.getOriginalFilename();

		// make a new directory
		boolean createDir = new File(destPath).mkdirs();

		// Move a file source to destination
		File moveFile = new File(destination);
		file.transferTo(moveFile);
		
		user.setFile(destination);
		
		userrepo.save(user);
		return "redirect:/register?success";
	}
}
