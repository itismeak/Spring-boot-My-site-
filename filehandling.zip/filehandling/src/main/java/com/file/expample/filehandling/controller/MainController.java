package com.file.expample.filehandling.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class MainController {

	@RequestMapping("/")
	public String showFile() {
		return "file";
	}

	@RequestMapping("/upload")
	public String upload(Model model, @RequestParam("files") MultipartFile file) throws IOException {
		String destPath = "D:/file handling/uploads/";
		
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("MMM_dd_yyyy hh_mm_ss-");
		String strDate = dateFormat.format(date);

		String destination=destPath + strDate + file.getOriginalFilename();
		String fileName= strDate + file.getOriginalFilename();
		// make a new directory
		boolean destDirectory = new File(destPath).mkdirs();

		// Move a file source to destination
		File moveFile = new File(destination);
		file.transferTo(moveFile);

		// Response msg will display HTML page
		model.addAttribute("msg", "Succesfully uploaded  " + destination);

		return "uploadstatusview";

	}

}
